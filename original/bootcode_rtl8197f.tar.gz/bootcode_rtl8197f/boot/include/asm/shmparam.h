/* $Id: shmparam.h,v 1.1 2009/11/13 13:22:46 jasonwang Exp $
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file "COPYING" in the main directory of this archive
 * for more details.
 */
#ifndef _ASM_SHMPARAM_H
#define _ASM_SHMPARAM_H

#define	SHMLBA 0x40000			/* attach addr a multiple of this */

#endif /* _ASM_SHMPARAM_H */
