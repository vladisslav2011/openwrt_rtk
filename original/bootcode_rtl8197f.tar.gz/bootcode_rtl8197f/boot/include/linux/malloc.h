#ifndef _LINUX_MALLOC_H
#define _LINUX_MALLOC_H

#include <linux/slab.h>
#endif /* _LINUX_MALLOC_H */
