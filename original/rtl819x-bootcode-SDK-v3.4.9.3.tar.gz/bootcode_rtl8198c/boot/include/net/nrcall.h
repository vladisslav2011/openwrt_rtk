/* Separate to keep compilation of protocols.c simpler */
extern void nr_proto_init(struct net_proto *pro);
