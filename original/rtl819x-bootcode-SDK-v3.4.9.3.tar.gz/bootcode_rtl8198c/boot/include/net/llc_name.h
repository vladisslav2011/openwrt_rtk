char *frame_names[] =
    {"I_CMD","RR_CMD","RNR_CMD","REJ_CMD","DISC_CMD",
    "SABME_CMD","I_RSP","RR_RSP","RNR_RSP","REJ_RSP",
    "UA_RSP","DM_RSP","FRMR_RSP","BAD_FRAME","UI_CMD",
    "XID_CMD","TEST_CMD","XID_RSP","TEST_RSP"
};
 
