/* Separate to keep compilation of protocols.c simpler */
extern void ax25_proto_init(struct net_proto *pro);
