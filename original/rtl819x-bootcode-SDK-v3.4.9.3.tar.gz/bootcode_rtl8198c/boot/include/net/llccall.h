/* Separate to keep compilation of protocols.c simpler */
extern void llc_init(struct net_proto *pro);

