/* Separate to keep compilation of protocols.c simpler */
extern void spx_proto_init(struct net_proto *pro);
