/* Separate to keep compilation of protocols.c simpler */
extern void irda_proto_init(struct net_proto *pro);
