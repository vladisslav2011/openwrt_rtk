#ifndef _ASM_SEGMENT_H
#define _ASM_SEGMENT_H

/* Only here because we have some old header files that expect it.. */

#endif /* _ASM_SEGMENT_H */
