#ifndef __ASM_MIPS_SMP_H
#define __ASM_MIPS_SMP_H

#define cpu_logical_map(cpu)	(cpu)

#endif /* __ASM_MIPS_SMP_H */
